// Zero-dependency local dev server.  Run:  node server.js   (or npm start)
// - Serves the site from this folder
// - Clean URLs: /calculator → calculator.html
// - Referral links: /r/ABC123 → /?ref=ABC123
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT) || 5173;
const ROOT = __dirname;
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon', '.woff2': 'font/woff2',
};
const BLOCKED = /^\/(node_modules|tests|tools|data|\.git)(\/|$)|^\/(server\.js|package\.json)$/;

http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  let p = decodeURIComponent(url.pathname);

  const ref = p.match(/^\/r\/([A-Za-z0-9]{4,12})\/?$/);
  if (ref) { res.writeHead(302, { Location: `/?ref=${ref[1].toUpperCase()}` }); return res.end(); }
  if (BLOCKED.test(p)) return send404(res);
  if (p.endsWith('/')) p += 'index.html';
  if (!path.extname(p)) p += '.html';

  const file = path.normalize(path.join(ROOT, p));
  if (!file.startsWith(ROOT)) return send404(res);
  fs.readFile(file, (err, buf) => {
    if (err) return send404(res);
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(buf);
  });
}).listen(PORT, () => console.log(`\n  Eutility savings site → http://localhost:${PORT}\n`));

function send404(res) {
  fs.readFile(path.join(ROOT, '404.html'), (e, buf) => {
    res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(e ? 'Not found' : buf);
  });
}
