# Eutility Savings Subsite — local prototype

A working, mobile-first build of the Eutility savings comparison + SME load-aggregation subsite, based on:

- **Creative Brief v2.0** (Website Requirements – Eutility Singapore) — UX, colours, type, motion, WhatsApp handoff
- **Price comparison sheet** (Plans + Promotions tabs) — all 36 residential plans and current promos
- **V1 Figma wireframes** — Residential | SME toggle, SME multi-site flow, Referrals page

Plain HTML/CSS/JavaScript with **no dependencies and no build step**, so it runs anywhere and ports easily to WordPress or Webflow later.

---

## Run it locally

You need Node 18+ (or Python 3).

```bash
cd eutility-savings
npm start            # → http://localhost:5173
# or, without Node:
python3 -m http.server 5173
```

`npm start` is better: it also handles clean URLs (`/calculator`) and referral links (`/r/ABC123`).
Don't open the HTML files directly with `file://`. The browser blocks JavaScript modules that way.

Run the tests for the pricing maths:

```bash
npm test             # 11 tests: fixed, discount-off-tariff, time-of-use, tiered, daily charge, SME tiers
```

## What this is

A frontend-first prototype of Eutility's **customer platform**, not just a calculator:
discover plans → check savings → sign up → upload your bill → keep a profile → earn rewards.
Customer data, bills and rewards are **mock** (stored in the visitor's browser through the
services layer) so the screens can be reviewed before any backend exists.

```
UI (pages, widgets)  →  services/  →  data
                         plans-service.js   → assets/js/data/plans.js (generated from the Excel sheet)
                         customer.js        → store.js → localStorage   (later: API + CRM)
                         rewards.js         → store.js + sample data    (later: referral backend)
```

Nothing above the services layer knows where data comes from, so swapping in a real API
means editing `assets/js/services/*` only.

## Pages

| Page | File | What it does |
|---|---|---|
| Home | `index.html` | Hero + quick calculator, what Eutility does, Singapore imagery, plan teaser, testimonials, 3 steps, account and rewards teasers |
| Explore Plans | `plans.html` | Browse all 34 comparable plans: usage slider, type chips (fixed / no lock-in / green / night saver / discount-off-tariff / promotions), retailer filter, sort; plan cards with the estimated monthly bill; a detail sheet with rates, contract, deposit, early termination fee, promo and source |
| Create account | `signup.html` | 4-step wizard: your details → your home (address, postal, home type) → electricity (retailer, plan, usage, SP account) → bill upload, then review + consent. Saves the customer, runs a savings check and offers a WhatsApp confirmation |
| My account | `account.html` | Dashboard: profile, electricity details, saved savings checks, uploaded bills, rewards progress, sign out / clear demo data |
| Savings Calculator | `calculator.html` | **Residential**: usage slider, retailer → plan, contract filter, green-only, time-of-use assumption. Shows a "thinking" loader, then the count-up reveal, current vs recommended plan, promos, an animated bar chart and a table of every plan. **SME** (`#sme`): company name, add/remove sites, running total, volume-tier bar, estimated savings, "Talk to Eutility" |
| How It Works | `how-it-works.html` | Four-step scroll journey: WhatsApp chat mockup, bill-scan animation, savings count-up, confetti |
| Eutility Rewards | `referrals.html` | **Leaderboard first**, then your progress towards the next reward, your link (copy / share), reward placeholders, recent activity and how it works |
| Testimonials | `testimonials.html` | Grid of testimonial cards |
| FAQ | `faq.html` | Search, grouped accordion, "Still have questions? WhatsApp us" |
| About & Contact | `about.html` | Story, mission, team, WhatsApp / email / phone |
| Legal | `legal.html` | Privacy and Terms placeholders |

Brief features that are built:

- WhatsApp handoff with a pre-filled message. On desktop it shows a **QR code** so the user can continue on their phone.
- Sticky WhatsApp bar at the bottom on mobile.
- Hamburger menu and sticky header.
- Count-up animation lasting 1.5 s.
- Confetti when savings are more than S$100 a year.
- An optional "ding" sound. It is off by default and the user turns it on.
- Pulsing **Switch Now** button (blue, per Figma).
- Fade-and-slide reveals as you scroll.
- All motion is switched off when the user's device asks for reduced motion.

## Customer journey

```
Visitor → Explore plans ─┐
                         ├→ Check savings → Sign up → Upload bill → Confirm on WhatsApp → Switch
Visitor → Calculator ────┘                     ↓
                                          My account (profile · checks · bills · rewards)
```

## Motion & usability (v3)

- **Page transitions:** pages cross-fade when you move between them (Chrome, Edge, Safari 18+). A logo loader shows on the first visit of each session (max 1.8 s).
- **Header:** hides while scrolling down and comes back when scrolling up. There's also a back-to-top button, and the sticky WhatsApp bar slides away at the footer.
- **Hero:** the headline rises into place. The Residential | SME toggle has a sliding highlight. There's a looping strip of the retailers we compare.
- **Calculator:**
  - Home-type presets (HDB 3-room … Landed) move the slider smoothly for people who don't know their kWh.
  - A live "Your bill today is about S$X" updates as you slide.
  - A "?" tip explains what kWh means.
  - The result scrolls into view, and the saving is also shown as "≈ N months of electricity, on us".
  - Result cards animate in one after another.
- **Everywhere else:** buttons and cards lift slightly on hover, sections fade in as you scroll, and FAQ answers open and close smoothly (newer Chrome).
- **Speed:** internal pages are prefetched when you hover over or tap a link.
- **Reduced motion:** if the user's device is set to reduce motion, all of the above is switched off.

## Update the prices

The site reads its prices from `assets/js/data/plans.js`. That file is **generated from the Excel sheet**, so don't edit it by hand.

```bash
pip install openpyxl
python3 tools/build_data.py                         # uses data/price-comparison-sheet.xlsx
python3 tools/build_data.py path/to/new-sheet.xlsx  # or a newer copy
```

Keep the same column layout. Rows with the same Retailer + Plan Name are merged into one plan (time-of-use and tiered plans use one row per band). Promotions are matched to plans by Retailer + Plan Name.

## How savings are calculated (`assets/js/calc.js`)

`monthly bill = kWh × rate + daily charge × 30.4 days`, worked out for every plan. Savings are your current plan's bill minus the other plan's bill, × 12 for the yearly figure.

| Pricing type | Treatment |
|---|---|
| Fixed / Regulated | kWh × rate |
| Discount off tariff | `%` → tariff × (1 − d). Values marked `*` in the sheet are **cents off** → tariff − d |
| Time of use | You choose the share of usage in off-peak hours (default 30%). For Keppel "Nights + Weekends", weekends also count as off-peak |
| Tiered (Stack It Up 24) | Each band's rate applies only to the kWh inside that band (assumed — confirm with PacificLight) |
| Daily charge | Added on top (Easy Peasy, Easy Save, 9 to 9) |

- **Default filter:** contracts up to 24 months. Otherwise the 60-month Classic 60 would top most results. Users can choose "Any length".
- **Referral-only plans** (Keppel FIXED24 Special) are left out unless the user switches them on.
- **Promotions** are shown next to the recommended plan but are **not** added to the savings figure.
- **Flo Energy** is left out because its plan hasn't launched.

## ⚠️ Placeholders to replace before launch

| Item | Where |
|---|---|
| WhatsApp Business number (currently `6500000000`) | `assets/js/config.js` → `whatsappNumber` |
| Email and phone | `assets/js/config.js` |
| **SME aggregation tiers and discounts (made up)** | `assets/js/config.js` → `smeTiers`. The baseline is the best ≤24-month fixed residential rate in the sheet, which is also an assumption |
| Logo is in (314×112 PNG). A larger or SVG export would look sharper on high-resolution screens | `assets/img/eutility-logo.png`, symbol + favicons in `assets/img/` |
| Home-type usage presets are rounded estimates | `assets/js/config.js` → `homePresets`. Confirm against EMA's latest statistics |
| Hero illustration → real Singapore photography or cinemagraph | `assets/img/hero-hdb.svg` (made by `tools/make_hero_svg.py`) |
| **Testimonials are samples.** Each card has a visible "Sample" label | `assets/js/data/testimonials.js`. Use real, permission-cleared quotes only |
| Rewards: leaderboard, counters, activity and the "next reward at 7 switches" target are samples | `assets/js/services/rewards.js`, `assets/js/config.js` → `rewards`. Reward values and qualifying rules deliberately left blank until Eutility confirms them |
| Customer accounts, bills and saved checks live in the browser only — no login, no database | `assets/js/services/customer.js` + `store.js` |
| Team photos and bios | `about.html` |
| Privacy Policy and Terms text | `legal.html` |
| FAQ answers are drafts (switching process, fees, data handling) | `assets/js/pages/faq.js` |
| Chat icon is generic | `assets/js/icons.js` → `chat`. Swap in the official WhatsApp glyph from Meta's brand resources if you want the logo |

## Design updates from Figma (Sep 2026)

- Primary blue **#26649B** (buttons, links, active nav), navy **#294671** (footer, selected toggle). Serif headlines are **#212121**.
- Official "eutility / get control" logo in the header. The footer has no logo, matching Figma.
- On mobile there's a tab strip under the header (Savings Calculator · How It Works · Referrals · FAQ). The desktop header is logo · nav · Check My Savings.
- The homepage hero has the "Check your savings" card with the Residential | SME toggle. Residential shows the calculator right in the card; SME links through to the SME calculator. Below it are the wide image and the referral banner.
- Orange buttons use bright **#F57C00**.
- Referral card: "Your referral link" title, Copy Link as the main button, Share on WhatsApp as an outline button. Stats cards have soft shadows.
- **Switch Now** is blue (Figma) instead of the brief's pulsing red. To go back to red, change `.btn--urgent` in `styles.css`.
- **Contrast:** white text on #F57C00 orange is about 2.9:1, below the WCAG AA 4.5:1 for normal text. If you need AA, use a deeper orange such as #C25E00.

## Where this differs from the brief

- **Navigation:** Savings Calculator · How It Works · Referrals · FAQ, plus a **Check My Savings** button. WhatsApp sits in the footer and the sticky mobile bar. This follows the V1 wireframe, which gives Referrals and SME a home. Testimonials and About are in the footer and the mobile menu.
- **Colours** now follow the Figma file (see above). All colours are variables at the top of `assets/css/styles.css`.
- **Fonts:** Canela / Freight Display are paid fonts, so **Newsreader** stands in and **Inter** is used for everything else. Both are stored in the project and load without internet. To switch fonts, change `--font-serif`.

## Project structure

```
index.html, calculator.html, how-it-works.html, referrals.html,
testimonials.html, faq.html, about.html, legal.html, 404.html
server.js                 zero-dependency dev server (clean URLs, /r/CODE referral links)
assets/
  css/styles.css          design tokens + all components
  js/config.js            ← edit: WhatsApp number, contacts, SME tiers, defaults
  js/calc.js              pricing engine (pure functions, unit-tested)
  js/layout.js            header, menu, footer, WhatsApp handoff + QR, referral capture, reveals
  js/fx.js                count-up, confetti, sound
  js/widgets/             residential calculator, SME calculator, testimonial card
  js/pages/               one small script per page
  js/data/plans.js        GENERATED from the price sheet
  js/data/testimonials.js sample content
  fonts/, img/, vendor/qrcode.js (MIT)
data/price-comparison-sheet.xlsx
tools/build_data.py       Excel → plans.js
tests/calc.test.mjs
```

## Next steps

1. Put in the real WhatsApp number and logo, then test the handoff on a phone.
2. Confirm the SME pricing tiers with Eutility's commercial team.
3. Decide on the CMS. Pages are plain HTML sections, so they can be moved into WordPress blocks or Webflow. `calc.js` + `plans.js` can be dropped in as-is.
4. Build the referral backend: issue codes, attribute sign-ups, count rewards.
5. Add analytics events: `calc_completed`, `switch_clicked`, `whatsapp_clicked`, `sme_lead`, `referral_shared`.
