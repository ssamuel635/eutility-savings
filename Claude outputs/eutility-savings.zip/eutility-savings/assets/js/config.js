// ─────────────────────────────────────────────────────────────
// Site configuration — edit these before going live.
// Anything marked TODO is a placeholder that must be confirmed by Eutility.
// ─────────────────────────────────────────────────────────────

export const CONFIG = {
  brand: 'Eutility',

  // TODO: Eutility's WhatsApp Business number in international format, digits only (no +, spaces).
  whatsappNumber: '6597908347',

  // Pre-filled message for the WhatsApp handoff (from the creative brief §6).
  whatsappDefaultMessage: 'Hi, I want to check my electricity savings',

  // TODO: confirm public contact details.
  email: 'customerservice@eutility.com.sg',
  phone: '+65 97908347',

  // Base URL used for referral links shown to users.
  referralBase: 'eutility.sg/r/',

  // Calculator defaults
  defaultKwh: 450,
  minKwh: 50,
  maxKwh: 2000,
  daysPerMonth: 30.4,

  // "Not sure of your usage?" presets — rounded, approximate monthly averages by home type
  // (starting points only; the user can fine-tune with the slider).
  // TODO: confirm against EMA's latest Singapore Energy Statistics (Chapter 3) before launch.
  homePresets: [
    { label: 'HDB 3-room', kwh: 280 },
    { label: 'HDB 4-room', kwh: 370 },
    { label: 'HDB 5-room', kwh: 440 },
    { label: 'Executive', kwh: 500 },
    { label: 'Condo', kwh: 500 },
    { label: 'Landed', kwh: 1100 },
  ],

  // Default share of usage that falls in off-peak hours, used for time-of-use plans.
  defaultOffPeakShare: 0.3,

  // ── Rewards / referral programme (TODO: confirm mechanics with Eutility) ──
  rewards: {
    programmeName: 'Eutility Rewards',   // customer-facing name for the referral programme
    nextRewardAt: 7,                     // PLACEHOLDER: switches needed for the next reward tier
  },

  // Confetti fires when yearly savings exceed this (brief §3.5 / §6).
  confettiThreshold: 100,

  // ── SME aggregation (TODO: placeholder commercial terms — confirm with Eutility) ──
  // Indicative aggregated rate = best ≤24-month fixed residential rate in the sheet
  // minus the tier discount below, applied to the COMBINED monthly usage of all sites.
  smeTiers: [
    { minKwh: 0, discountPct: 0, label: 'Starter' },
    { minKwh: 2000, discountPct: 2, label: 'Bronze' },
    { minKwh: 10000, discountPct: 4, label: 'Silver' },
    { minKwh: 50000, discountPct: 6, label: 'Gold' },
  ],
  smeMaxSites: 20,
};

export function waLink(message = CONFIG.whatsappDefaultMessage) {
  return `https://wa.me/${CONFIG.whatsappNumber}?text=${encodeURIComponent(message)}`;
}
