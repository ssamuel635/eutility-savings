// Shared shell: header, mobile drawer, footer, sticky WhatsApp bar,
// WhatsApp handoff (+ desktop QR fallback), referral capture, scroll reveals, toast.
import { CONFIG, waLink } from './config.js';
import { META } from './data/plans.js';
import * as I from './icons.js';
import * as customer from './services/customer.js';

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function initials() {
  const n = (customer.get()?.fullName || '').trim();
  if (!n) return 'E';
  const parts = n.split(/\s+/);
  return ((parts[0][0] || '') + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
}

const NAV = [
  { href: 'calculator.html', label: 'Savings Calculator', key: 'calculator' },
  { href: 'plans.html', label: 'Explore Plans', key: 'plans' },
  { href: 'referrals.html', label: 'Rewards', key: 'referrals' },
  { href: 'how-it-works.html', label: 'How It Works', key: 'how' },
  { href: 'faq.html', label: 'FAQ', key: 'faq' },
];

export const store = {
  get(k) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch { /* private mode */ } },
};

// Official logo exported from Figma → assets/img/eutility-logo.png (PNG @2x or SVG).
// Until the file is added, a text wordmark is shown instead.
const LOGO_SRC = 'assets/img/eutility-logo.png';
const wordmark = '<span class="logo-word" aria-hidden="true"><span>e<b>u</b>tility</span><small>get control</small></span>';
function logo() {
  return `<img src="${LOGO_SRC}" alt="Eutility — get control" width="314" height="112" decoding="async" data-logo-img>`;
}
function wireLogoFallback() {
  document.querySelectorAll('img[data-logo-img]').forEach((img) => {
    const swap = () => { img.outerHTML = wordmark; };
    if (img.complete && img.naturalWidth === 0) swap();
    else img.addEventListener('error', swap, { once: true });
  });
}

function header(page) {
  const links = NAV.map((n) => `<a href="${n.href}"${n.key === page ? ' aria-current="page"' : ''}>${n.label}</a>`).join('');
  return `
  <a class="skip-link" href="#main">Skip to content</a>
  <header class="site-header" id="top">
    <div class="site-header__inner">
      <a class="logo" href="index.html" aria-label="Eutility home">${logo()}</a>
      <nav class="site-nav" aria-label="Main">${links}</nav>
      <div class="header-actions">
        ${customer.isSignedIn()
          ? `<a class="account-chip" href="account.html" aria-label="Your account"><span class="account-chip__avatar">${initials()}</span><span class="account-chip__name">${esc(customer.firstName() || 'Account')}</span></a>`
          : `<a class="btn btn--ghost btn--sm header-account" href="signup.html">Sign up</a>`}
        <a class="btn btn--sm header-cta" href="calculator.html">Check My Savings</a>
        <button class="menu-btn" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="drawer">${I.menu}</button>
      </div>
    </div>
    <nav class="mobile-nav" aria-label="Sections">${links}</nav>
  </header>
  <div class="drawer" id="drawer" aria-hidden="true">
    <div class="drawer__scrim" data-close></div>
    <div class="drawer__panel" role="dialog" aria-modal="true" aria-label="Menu">
      <div class="drawer__top">
        <a class="logo" href="index.html" aria-label="Eutility home">${logo()}</a>
        <button class="menu-btn" type="button" aria-label="Close menu" data-close>${I.close}</button>
      </div>
      <nav aria-label="Mobile">
        <a href="index.html"${page === 'home' ? ' aria-current="page"' : ''}>Home</a>
        ${links}
        <a href="${customer.isSignedIn() ? 'account.html' : 'signup.html'}"${page === 'account' || page === 'signup' ? ' aria-current="page"' : ''}>${customer.isSignedIn() ? 'My account' : 'Sign up'}</a>
        <a href="testimonials.html"${page === 'testimonials' ? ' aria-current="page"' : ''}>Testimonials</a>
        <a href="about.html"${page === 'about' ? ' aria-current="page"' : ''}>About &amp; Contact</a>
      </nav>
      <a class="btn btn--block" href="calculator.html">Check My Savings</a>
      <a class="btn btn--secondary btn--block" href="${customer.isSignedIn() ? 'account.html' : 'signup.html'}">${customer.isSignedIn() ? 'My account' : 'Sign up'}</a>
      <a class="btn btn--neutral btn--block" href="${waLink()}" data-wa>${I.chat}<span>Chat on WhatsApp</span></a>
    </div>
  </div>`;
}

function footer() {
  const year = new Date().getFullYear();
  return `
  <footer class="site-footer">
    <div class="container">
      <div class="site-footer__grid">
        <div class="stack" style="--stack:16px">
          <p>Helping Singapore homes and businesses pay less for electricity.</p>
        </div>
        <div>
          <h3>Product</h3>
          <ul>
            <li><a href="calculator.html">Savings Calculator</a></li>
            <li><a href="calculator.html#sme">For Businesses (SME)</a></li>
            <li><a href="how-it-works.html">How It Works</a></li>
            <li><a href="plans.html">Explore Plans</a></li>
            <li><a href="referrals.html">${CONFIG.rewards.programmeName}</a></li>
            <li><a href="testimonials.html">Testimonials</a></li>
          </ul>
        </div>
        <div>
          <h3>Support</h3>
          <ul>
            <li><a href="faq.html">FAQ</a></li>
            <li><a href="about.html#contact">Contact us</a></li>
            <li><a href="about.html">About Eutility</a></li>
            <li><a href="signup.html">Create an account</a></li>
            <li><a href="legal.html#privacy">Privacy Policy</a></li>
            <li><a href="legal.html#terms">Terms</a></li>
          </ul>
        </div>
        <div class="stack" style="--stack:14px">
          <h3>Talk to us</h3>
          <p>Questions? We reply on WhatsApp.</p>
          <a class="btn btn--white" href="${waLink()}" data-wa>${I.chat}<span>Chat on WhatsApp</span></a>
          <p><a href="mailto:${CONFIG.email}">${CONFIG.email}</a></p>
        </div>
      </div>
      <div class="site-footer__legal">
        <span>© ${year} Eutility. All rights reserved.</span>
        <span>Savings are estimates based on published retailer rates (data updated ${META.generated}).</span>
      </div>
    </div>
  </footer>
  <div class="wa-bar"><a href="${waLink()}" data-wa>${I.chat.replace('class="icon"', '')}<span>Chat on WhatsApp</span></a></div>
  <div class="modal" id="wa-modal" aria-hidden="true">
    <div class="modal__scrim" data-close></div>
    <div class="modal__panel" role="dialog" aria-modal="true" aria-labelledby="wa-modal-title">
      <button class="modal__close" type="button" aria-label="Close" data-close>×</button>
      <h2 class="h3" id="wa-modal-title">Continue on WhatsApp</h2>
      <p class="small">Scan with your phone camera to open the chat with your message ready to send.</p>
      <div class="qr" id="wa-qr" role="img" aria-label="QR code linking to Eutility on WhatsApp"></div>
      <a class="btn btn--block" id="wa-open" href="#" target="_blank" rel="noopener">${I.chat}<span>Open WhatsApp on this computer</span></a>
      <p class="small">No WhatsApp? Email <a href="mailto:${CONFIG.email}">${CONFIG.email}</a></p>
    </div>
  </div>
  <div class="toast" role="status" aria-live="polite" id="toast"></div>`;
}

// ── Toast ──
let toastTimer;
export function toast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('is-shown');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('is-shown'), 2400);
}

// ── Referral capture: ?ref=CODE (also /r/CODE via server rewrite) ──
export function referredBy() { return store.get('eu_referred_by'); }
function captureReferral() {
  const code = new URLSearchParams(location.search).get('ref');
  if (code && /^[A-Z0-9]{4,12}$/i.test(code)) {
    store.set('eu_referred_by', code.toUpperCase());
    const n = document.createElement('div');
    n.className = 'ref-notice';
    n.setAttribute('role', 'status');
    n.textContent = `A friend referred you — code ${code.toUpperCase()} will be added when you chat with us.`;
    document.querySelector('.site-header')?.after(n);
  }
}

// ── WhatsApp handoff (brief §6) ──
export function buildWaMessage(msg = CONFIG.whatsappDefaultMessage) {
  const ref = referredBy();
  return ref ? `${msg}\n(Referral code: ${ref})` : msg;
}
const isDesktop = () => window.matchMedia('(hover: hover) and (pointer: fine) and (min-width: 1024px)').matches;

export function openWhatsApp(message) {
  const url = waLink(buildWaMessage(message));
  if (!isDesktop()) {
    window.open(url, '_blank', 'noopener');
    return;
  }
  const modal = document.getElementById('wa-modal');
  const qrBox = document.getElementById('wa-qr');
  document.getElementById('wa-open').href = url;
  qrBox.innerHTML = '';
  if (window.qrcode) {
    const qr = window.qrcode(0, 'M');
    qr.addData(url);
    qr.make();
    qrBox.innerHTML = qr.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
  } else {
    qrBox.textContent = 'QR unavailable';
  }
  openLayer(modal);
}

function openLayer(el, trigger) {
  el.classList.add('is-open');
  el.setAttribute('aria-hidden', 'false');
  el._trigger = trigger || document.activeElement;
  document.body.style.overflow = 'hidden';
  const focusable = el.querySelector('a, button');
  setTimeout(() => focusable?.focus(), 50);
}
function closeLayer(el) {
  el.classList.remove('is-open');
  el.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
  el._trigger?.focus?.();
}

// ── Scroll reveals ──
export function observeReveals(root = document) {
  // [data-stagger] parents give each .reveal child an increasing delay
  root.querySelectorAll('[data-stagger], .steps, .grid-3, .stats, .team').forEach((p) => {
    [...p.children].forEach((c, i) => { c.classList.add('reveal'); c.style.setProperty('--d', `${i * 0.08}s`); });
  });
  const els = root.querySelectorAll('.reveal, [data-inview]');
  if (!('IntersectionObserver' in window)) {
    els.forEach((e) => e.classList.add('is-visible'));
    return;
  }
  const io = new IntersectionObserver((entries) => {
    for (const en of entries) {
      if (en.isIntersecting) {
        en.target.classList.add('is-visible');
        en.target.dispatchEvent(new CustomEvent('inview'));
        io.unobserve(en.target);
      }
    }
  }, { threshold: 0.05, rootMargin: '0px 0px -40px 0px' });
  els.forEach((e) => io.observe(e));
}

// ── First-visit loader (once per browser session, brief §3.6) ──
function showLoader() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  try {
    if (sessionStorage.getItem('eu_loader')) return;
    sessionStorage.setItem('eu_loader', '1');
  } catch { return; }
  const l = document.createElement('div');
  l.className = 'loader';
  l.setAttribute('aria-hidden', 'true');
  l.innerHTML = `<div><img src="${LOGO_SRC}" alt=""><div class="loader__bar"></div></div>`;
  document.body.appendChild(l);
  let finished = false;
  const done = () => { if (finished) return; finished = true; l.classList.add('is-done'); setTimeout(() => l.remove(), 500); };
  if (document.readyState === 'complete') setTimeout(done, 600);
  else addEventListener('load', () => setTimeout(done, 300), { once: true });
  setTimeout(done, 1800); // never block for long
}

// ── Header hides on scroll down, returns on scroll up ──
function smartHeader() {
  const hdr = document.querySelector('.site-header');
  let last = scrollY, ticking = false;
  const update = () => {
    const y = scrollY;
    hdr.classList.toggle('is-scrolled', y > 4);
    const openLayer = document.querySelector('.drawer.is-open, .modal.is-open');
    if (!openLayer) hdr.classList.toggle('is-hidden', y > last && y > 240);
    last = y;
    ticking = false;
  };
  addEventListener('scroll', () => { if (!ticking) { requestAnimationFrame(update); ticking = true; } }, { passive: true });
  update();
}

// ── Back-to-top + hide sticky WhatsApp bar near the footer ──
function extras() {
  const btn = document.createElement('button');
  btn.className = 'to-top';
  btn.type = 'button';
  btn.setAttribute('aria-label', 'Back to top');
  btn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V5M5 12l7-7 7 7"/></svg>';
  btn.addEventListener('click', () => scrollTo({ top: 0, behavior: 'smooth' }));
  document.body.appendChild(btn);
  addEventListener('scroll', () => btn.classList.toggle('is-shown', scrollY > 900), { passive: true });

  const bar = document.querySelector('.wa-bar');
  const foot = document.querySelector('.site-footer');
  if ('IntersectionObserver' in window && bar && foot) {
    new IntersectionObserver(([en]) => bar.classList.toggle('is-away', en.isIntersecting)).observe(foot);
  }
}

// ── Faster page loads: prefetch internal pages on hover / when idle ──
function prefetchLinks() {
  const done = new Set([location.pathname]);
  const prefetch = (href) => {
    const u = new URL(href, location.href);
    if (u.origin !== location.origin || done.has(u.pathname) || !u.pathname.endsWith('.html')) return;
    done.add(u.pathname);
    const l = document.createElement('link');
    l.rel = 'prefetch';
    l.href = u.pathname;
    document.head.appendChild(l);
  };
  document.addEventListener('pointerover', (e) => { const a = e.target.closest('a[href]'); if (a) prefetch(a.href); }, { passive: true });
  document.addEventListener('touchstart', (e) => { const a = e.target.closest('a[href]'); if (a) prefetch(a.href); }, { passive: true });
}

export function initLayout() {
  document.documentElement.classList.remove('no-js');
  const page = document.body.dataset.page;
  document.body.insertAdjacentHTML('afterbegin', header(page));
  document.body.insertAdjacentHTML('beforeend', footer());

  wireLogoFallback();
  showLoader();
  smartHeader();
  extras();
  prefetchLinks();

  const drawer = document.getElementById('drawer');
  const menuBtn = document.querySelector('.header-actions .menu-btn');
  menuBtn.addEventListener('click', () => { openLayer(drawer, menuBtn); menuBtn.setAttribute('aria-expanded', 'true'); });
  document.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => {
    const layer = b.closest('.drawer, .modal');
    closeLayer(layer);
    if (layer === drawer) menuBtn.setAttribute('aria-expanded', 'false');
  }));
  addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    document.querySelectorAll('.drawer.is-open, .modal.is-open').forEach(closeLayer);
    menuBtn.setAttribute('aria-expanded', 'false');
  });

  // Any element with data-wa opens WhatsApp; data-wa-message overrides the text.
  document.addEventListener('click', (e) => {
    const a = e.target.closest('[data-wa]');
    if (!a) return;
    e.preventDefault();
    openWhatsApp(a.dataset.waMessage || undefined);
  });

  captureReferral();
  observeReveals();
}
