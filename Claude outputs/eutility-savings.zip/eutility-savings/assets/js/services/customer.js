// Customer service — sign-up, profile, electricity details, bill uploads and
// saved savings checks. Mock only: everything lives in this browser (see store.js).
// Replace the store calls with API calls when the backend exists; the page code
// below the service does not change.

import { store, uid, nowISO, MOCK } from './store.js';

const KEY = 'customer';
const CHECKS = 'savings-checks';
const BILLS = 'bills';

export const DWELLINGS = ['HDB 1–2 room', 'HDB 3-room', 'HDB 4-room', 'HDB 5-room', 'HDB Executive', 'Condominium / Apartment', 'Landed property', 'Business premises'];

export function isSignedIn() { return !!get(); }
export function get() { return store.read(KEY); }

/** Create (or update) the local customer record. Returns the saved customer. */
export function signUp(profile) {
  const existing = get();
  const customer = {
    id: existing?.id || 'CUST-' + uid(6),
    createdAt: existing?.createdAt || nowISO(),
    updatedAt: nowISO(),
    referralCode: existing?.referralCode || uid(6),
    ...existing,
    ...profile,
  };
  store.write(KEY, customer);
  return customer;
}

export function update(patch) {
  const c = get();
  if (!c) return null;
  const next = { ...c, ...patch, updatedAt: nowISO() };
  store.write(KEY, next);
  return next;
}

export function signOut() { store.remove(KEY); }

/** Wipe everything this prototype stored on the device. */
export function clearDemoData() { store.clearAll(); }

export function firstName() {
  const n = get()?.fullName || '';
  return n.trim().split(/\s+/)[0] || '';
}

// ── Savings checks ───────────────────────────────────────────
/** Save the result of a calculator run so it shows up in the account. */
export function saveCheck({ kwh, currentPlanId, currentPlanName, bestPlanId, bestPlanName, savingYearly, savingMonthly, type = 'residential' }) {
  const checks = listChecks();
  const record = {
    id: 'CHK-' + uid(6),
    at: nowISO(),
    type, kwh, currentPlanId, currentPlanName, bestPlanId, bestPlanName, savingYearly, savingMonthly,
  };
  store.write(CHECKS, [record, ...checks].slice(0, 20));
  return record;
}
export function listChecks() { return store.read(CHECKS, []) || []; }
export function latestCheck() { return listChecks()[0] || null; }

// ── Bill uploads ─────────────────────────────────────────────
/**
 * Store a bill. In the prototype the file is kept as a data URL in this browser
 * (images/PDFs under ~2 MB). A real build uploads to storage and keeps only the URL.
 */
export async function addBill(file) {
  const meta = { id: 'BILL-' + uid(6), name: file.name, size: file.size, type: file.type, at: nowISO() };
  if (MOCK && file.size <= 2 * 1024 * 1024 && file.type.startsWith('image/')) {
    meta.dataUrl = await new Promise((res) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.onerror = () => res(null);
      r.readAsDataURL(file);
    });
  }
  const bills = listBills();
  store.write(BILLS, [meta, ...bills].slice(0, 5));
  return meta;
}
export function listBills() { return store.read(BILLS, []) || []; }
export function latestBill() { return listBills()[0] || null; }

// ── Validation helpers used by the sign-up form ──────────────
export const validators = {
  fullName: (v) => (v.trim().length >= 2 ? '' : 'Please enter your full name.'),
  email: (v) => (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'Please enter a valid email address.'),
  phone: (v) => (/^(\+?65)?[\s-]?[689]\d{3}[\s-]?\d{4}$/.test(v.trim()) ? '' : 'Enter a Singapore mobile number, e.g. 9123 4567.'),
  address: (v) => (v.trim().length >= 5 ? '' : 'Please enter your street address.'),
  postal: (v) => (/^\d{6}$/.test(v.trim()) ? '' : 'Singapore postal codes have 6 digits.'),
  kwh: (v) => (Number(v) >= 50 && Number(v) <= 5000 ? '' : 'Enter a usage between 50 and 5,000 kWh.'),
};
