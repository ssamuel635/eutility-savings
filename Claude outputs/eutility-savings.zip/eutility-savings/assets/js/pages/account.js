// Customer dashboard (mock): profile, electricity details, saved savings checks,
// bills and a rewards snapshot. All data comes from the services layer.
import { initLayout, openWhatsApp, toast } from '../layout.js';
import { CONFIG } from '../config.js';
import { getPlan, fmtMoney, rateLabel, contractLabel } from '../calc.js';
import * as customer from '../services/customer.js';
import * as rewards from '../services/rewards.js';
import * as I from '../icons.js';

initLayout();

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const root = document.getElementById('account-root');
const fmtDate = (iso) => new Date(iso).toLocaleDateString('en-SG', { day: 'numeric', month: 'short', year: 'numeric' });

function signedOut() {
  root.innerHTML = `
    <div class="stack text-center" style="--stack:18px;max-width:520px;margin-inline:auto;padding-block:clamp(32px,6vw,80px)">
      <span class="dash-avatar" style="margin-inline:auto">${I.user}</span>
      <h1 class="h1">Your account</h1>
      <p class="lead">Create an account to keep your savings checks, electricity details and rewards in one place.</p>
      <div class="stack" style="--stack:12px">
        <a class="btn btn--block" href="signup.html">Create my account</a>
        <a class="btn btn--secondary btn--block" href="calculator.html">Check my savings first</a>
      </div>
      <p class="small">Prototype: accounts are stored in this browser only — there's no login yet.</p>
    </div>`;
}

function dashboard() {
  const c = customer.get();
  const checks = customer.listChecks();
  const bills = customer.listBills();
  const cur = getPlan(c.currentPlanId);
  const target = getPlan(c.intendedPlanId);
  const st = rewards.myStatus();
  const best = checks[0];

  root.innerHTML = `
    <div class="stack" style="--stack:28px">
      <div class="stack" style="--stack:10px">
        <p class="eyebrow">My account</p>
        <h1 class="h1">Hello, ${esc(customer.firstName())}.</h1>
        <p class="lead">${best ? `Your last check found <strong class="text-orange">${fmtMoney(best.savingYearly)}</strong> a year in savings.` : 'You haven\'t run a savings check yet.'}</p>
      </div>

      <div class="dash-grid">
        <div class="stack" style="--stack:20px">
          <div class="dash-card">
            <div style="display:flex;gap:14px;align-items:center">
              <span class="dash-avatar">${esc((c.fullName || 'E').trim().split(/\\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase())}</span>
              <div>
                <strong style="display:block;font-size:17px;color:var(--text)">${esc(c.fullName)}</strong>
                <span class="small">${esc(c.id)} · joined ${fmtDate(c.createdAt)}</span>
              </div>
            </div>
            <div class="review-list">
              <div><span>Email</span><span>${esc(c.email)}</span></div>
              <div><span>Mobile</span><span>${esc(c.phone)}</span></div>
              <div><span>Address</span><span>${esc([c.address, c.unit, 'Singapore ' + c.postal].filter(Boolean).join(', '))}</span></div>
              <div><span>Home type</span><span>${esc(c.dwelling || '—')}</span></div>
            </div>
            <a class="btn btn--neutral btn--block btn--sm" href="signup.html">Edit my details</a>
          </div>

          <div class="dash-card">
            <h2 class="h4">Rewards</h2>
            <div class="lb-light progress">
              <div style="display:flex;justify-content:space-between;font-size:14px"><span>${st.switched} of ${st.target} switches</span><span class="small">${st.toNext} to next reward</span></div>
              <div class="progress__track"><div class="progress__fill" style="width:${st.progressPct}%"></div></div>
            </div>
            <p class="small">${esc(CONFIG.rewards.programmeName)} · sample figures until the programme goes live.</p>
            <a class="btn btn--secondary btn--block btn--sm" href="referrals.html">See the leaderboard</a>
          </div>
        </div>

        <div class="stack" style="--stack:20px">
          <div class="dash-card">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:12px">
              <h2 class="h4">My electricity</h2>
              <a class="link-arrow" href="calculator.html?kwh=${c.monthlyKwh}&plan=${esc(c.currentPlanId)}&run=1" style="font-size:14px">Re-check savings</a>
            </div>
            <div class="review-list">
              <div><span>Current plan</span><span>${cur ? `${esc(cur.retailer)} · ${esc(cur.name)}` : '—'}</span></div>
              <div><span>Price</span><span>${cur ? esc(rateLabel(cur)) : '—'}</span></div>
              <div><span>Contract</span><span>${cur ? esc(contractLabel(cur.contractMonths)) : '—'}</span></div>
              <div><span>Monthly usage</span><span>${Number(c.monthlyKwh || 0).toLocaleString('en-SG')} kWh</span></div>
              <div><span>SP account</span><span>${esc(c.accountNo || 'Not added')}</span></div>
              ${target ? `<div><span>Switching to</span><span>${esc(target.retailer)} · ${esc(target.name)}</span></div>` : ''}
            </div>
          </div>

          <div class="dash-card">
            <h2 class="h4">Savings checks</h2>
            ${checks.length ? checks.map((k) => `
              <div class="history-row">
                <div class="history-row__top">
                  <strong style="color:var(--text)">${esc(k.bestPlanName)}</strong>
                  <span class="history-row__save">${fmtMoney(k.savingYearly)}<span class="small" style="color:var(--muted)">/yr</span></span>
                </div>
                <span class="small">${fmtDate(k.at)} · ${Number(k.kwh).toLocaleString('en-SG')} kWh/month · from ${esc(k.currentPlanName)}</span>
              </div>`).join('')
            : `<div class="empty"><p>No checks saved yet</p><a class="btn btn--sm" href="calculator.html">Check my savings</a></div>`}
          </div>

          <div class="dash-card">
            <h2 class="h4">My bills</h2>
            ${bills.length ? bills.map((b) => `
              <div class="file-chip">
                ${b.dataUrl ? `<img src="${b.dataUrl}" alt="">` : `<span class="activity-row__icon">${I.upload}</span>`}
                <span class="file-chip__meta"><strong>${esc(b.name)}</strong><span class="small">${Math.round(b.size / 1024)} KB · ${fmtDate(b.at)}</span></span>
              </div>`).join('')
            : `<div class="empty"><p>No bill uploaded yet</p><a class="btn btn--sm btn--secondary" href="signup.html">Upload a bill</a></div>`}
            <p class="small">Prototype: bills are kept in this browser. A real build stores them securely and reads them automatically.</p>
          </div>

          <div class="dash-card">
            <h2 class="h4">Need a hand?</h2>
            <p>Our team can confirm your plan, check contract dates or handle the switch for you.</p>
            <button class="btn btn--wa btn--block" type="button" data-wa-help>${I.chat}<span>Chat on WhatsApp</span></button>
          </div>
        </div>
      </div>

      <div style="display:flex;gap:16px;flex-wrap:wrap;justify-content:space-between;border-top:1px solid var(--border);padding-top:20px">
        <p class="small" style="max-width:520px">This prototype keeps everything on this device. “Clear demo data” removes your profile, checks and bills from this browser.</p>
        <div style="display:flex;gap:12px">
          <button class="btn btn--neutral btn--sm" type="button" data-signout>Sign out</button>
          <button class="btn btn--neutral btn--sm" type="button" data-clear style="color:var(--red-aa)">Clear demo data</button>
        </div>
      </div>
    </div>`;

  root.querySelector('[data-wa-help]').addEventListener('click', () => openWhatsApp(
    `Hi Eutility, this is ${c.fullName} (${c.id}). I have a question about my account.`,
  ));
  root.querySelector('[data-signout]').addEventListener('click', () => { customer.signOut(); location.reload(); });
  root.querySelector('[data-clear]').addEventListener('click', () => {
    customer.clearDemoData();
    toast('Demo data cleared');
    setTimeout(() => location.reload(), 600);
  });
}

customer.isSignedIn() ? dashboard() : signedOut();
