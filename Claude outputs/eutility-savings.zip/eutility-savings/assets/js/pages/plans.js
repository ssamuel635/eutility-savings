import { initLayout, openWhatsApp, observeReveals } from '../layout.js';
import { CONFIG } from '../config.js';
import { META } from '../data/plans.js';
import { fmtMoney } from '../calc.js';
import * as plans from '../services/plans-service.js';
import * as customer from '../services/customer.js';

initLayout();

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const q = new URLSearchParams(location.search);

const state = {
  kwh: Number(q.get('kwh')) || customer.get()?.monthlyKwh || CONFIG.defaultKwh,
  type: plans.PLAN_TYPES[q.get('type')] ? q.get('type') : 'all',
  retailer: 'all',
  sort: 'price',
};

const toolbar = document.getElementById('plan-toolbar');
toolbar.innerHTML = `
  <div class="range-wrap">
    <label class="field__label" for="pl-kwh">Price plans for this usage</label>
    <div class="range-value"><output id="pl-out">${state.kwh}</output><span>kWh / month</span></div>
    <input class="range" type="range" id="pl-kwh" min="${CONFIG.minKwh}" max="${CONFIG.maxKwh}" step="10" value="${state.kwh}">
  </div>
  <div class="field">
    <label class="field__label" for="pl-retailer">Retailer</label>
    <select class="select" id="pl-retailer">
      <option value="all">All retailers</option>
      ${plans.retailers().map((r) => `<option value="${esc(r)}">${esc(r)}</option>`).join('')}
    </select>
  </div>
  <div class="field">
    <label class="field__label" for="pl-sort">Sort by</label>
    <select class="select" id="pl-sort">
      ${Object.entries(plans.SORTS).map(([k, s]) => `<option value="${k}">${s.label}</option>`).join('')}
    </select>
  </div>
  <div class="chips" style="grid-column:1/-1">
    ${Object.entries(plans.PLAN_TYPES).map(([k, t]) => `
      <span class="chip"><input type="radio" name="pl-type" id="pl-t-${k}" value="${k}"${k === state.type ? ' checked' : ''}><label for="pl-t-${k}">${t.label}</label></span>`).join('')}
  </div>`;

const grid = document.getElementById('plan-grid');
const count = document.getElementById('plan-count');
const basis = document.getElementById('plan-basis');
const kwhRange = document.getElementById('pl-kwh');
const kwhOut = document.getElementById('pl-out');

const paint = (el) => el.style.setProperty('--pct', `${((el.value - el.min) / (el.max - el.min)) * 100}%`);
paint(kwhRange);

function card(row, i, best) {
  const p = row.plan;
  return `
  <article class="plan-card${row.id === best ? ' plan-card--best' : ''} reveal" style="--d:${Math.min(i, 8) * 0.05}s">
    <div class="plan-card__top">
      <div>
        <p class="plan-card__retailer">${esc(p.retailer)}</p>
        <p class="plan-card__name">${esc(p.name)}</p>
      </div>
      <div class="plan-card__bill"><strong>${fmtMoney(row.monthly)}</strong><span>est. / month</span></div>
    </div>
    <div class="plan-card__tags">
      ${row.id === best ? '<span class="tag tag--green">Cheapest here</span>' : ''}
      ${row.tags.map((t) => `<span class="tag${t === 'Green' ? ' tag--green' : t === 'Promotion' ? ' tag--promo' : ''}">${esc(t)}</span>`).join('')}
    </div>
    <div class="plan-card__row"><span>Price</span><span>${esc(row.priceLabel)}</span></div>
    <div class="plan-card__row"><span>Contract</span><span>${esc(row.contract)}</span></div>
    <div class="plan-card__row"><span>vs SP tariff</span><span class="${row.savingVsTariffYearly >= 0 ? 'save-pos' : 'save-neg'}">${row.savingVsTariffYearly >= 0 ? 'Save ' : 'Costs '}${fmtMoney(Math.abs(row.savingVsTariffYearly))}/yr</span></div>
    <div class="plan-card__actions">
      <button class="btn btn--secondary btn--sm" type="button" data-detail="${row.id}">Details</button>
      <a class="btn btn--sm" href="signup.html?plan=${encodeURIComponent(row.id)}">Switch</a>
    </div>
  </article>`;
}

function render() {
  const rows = plans.list(state);
  const best = rows.length ? rows.slice().sort((a, b) => a.monthly - b.monthly)[0].id : null;
  grid.innerHTML = rows.length
    ? rows.map((r, i) => card(r, i, best)).join('')
    : `<div class="empty" style="grid-column:1/-1"><p class="h4" style="color:var(--text)">No plans match those filters</p><p>Try “All plans”, or ask us on WhatsApp.</p></div>`;
  count.textContent = `${rows.length} plan${rows.length === 1 ? '' : 's'}`;
  basis.textContent = `Estimated at ${state.kwh.toLocaleString('en-SG')} kWh/month · SP tariff ${plans.TARIFF}¢/kWh · prices updated ${META.generated}`;
  observeReveals(grid);
  const u = new URL(location.href);
  u.searchParams.set('kwh', state.kwh);
  u.searchParams.set('type', state.type);
  history.replaceState(null, '', u);
}

kwhRange.addEventListener('input', () => {
  state.kwh = Number(kwhRange.value);
  kwhOut.textContent = state.kwh.toLocaleString('en-SG');
  paint(kwhRange);
  render();
});
document.getElementById('pl-retailer').addEventListener('change', (e) => { state.retailer = e.target.value; render(); });
document.getElementById('pl-sort').addEventListener('change', (e) => { state.sort = e.target.value; render(); });
document.querySelectorAll('input[name="pl-type"]').forEach((r) => r.addEventListener('change', () => { state.type = r.value; render(); }));

// ── Plan detail sheet ──
const sheet = document.getElementById('plan-sheet');
const sheetBody = document.getElementById('sheet-body');

function openSheet(id) {
  const row = plans.detail(id, { kwh: state.kwh });
  if (!row) return;
  const p = row.plan;
  sheetBody.innerHTML = `
    <div class="stack" style="--stack:10px">
      <p class="plan-card__retailer">${esc(p.retailer)}</p>
      <h2 class="h2" id="sheet-title">${esc(p.name)}</h2>
      <div class="plan-card__tags">${row.tags.map((t) => `<span class="tag${t === 'Green' ? ' tag--green' : t === 'Promotion' ? ' tag--promo' : ''}">${esc(t)}</span>`).join('')}</div>
    </div>
    <div class="card card--blue" style="display:grid;gap:4px">
      <span class="small">Estimated bill at ${state.kwh.toLocaleString('en-SG')} kWh/month</span>
      <span style="font-size:34px;font-weight:700;letter-spacing:-.02em;color:var(--text)">${fmtMoney(row.monthly, 2)}<span class="small"> /month</span></span>
      <span class="small">Effective ${row.effectiveRate}¢/kWh including any daily charge</span>
    </div>
    <dl style="margin:0">
      <div class="spec"><dt>Price</dt><dd>${esc(row.priceLabel)}</dd></div>
      <div class="spec"><dt>Contract</dt><dd>${esc(row.contract)}</dd></div>
      <div class="spec"><dt>Plan type</dt><dd>${esc(p.pricingLabel || p.pricingType)}${p.category === 'Green' ? ' · Green energy' : ''}</dd></div>
      ${p.promo ? `<div class="spec"><dt>Promotion</dt><dd>${esc(p.promo.value || p.promo.title)}${p.promo.code ? ` · code <strong>${esc(p.promo.code)}</strong>` : ''}${p.promo.conditions ? `<br><span class="small">${esc(p.promo.conditions)}</span>` : ''}</dd></div>` : ''}
      <div class="spec"><dt>Early termination</dt><dd>${esc(p.etf || 'See retailer terms')}</dd></div>
      <div class="spec"><dt>Security deposit</dt><dd>${esc(p.deposit || 'See retailer terms')}</dd></div>
      ${p.notes?.length ? `<div class="spec"><dt>Good to know</dt><dd>${p.notes.map(esc).join('<br>')}</dd></div>` : ''}
      <div class="spec"><dt>Source</dt><dd>${esc(p.source || p.retailer)} price sheet, updated ${META.generated}</dd></div>
    </dl>
    <div class="stack" style="--stack:12px">
      <a class="btn btn--block" href="signup.html?plan=${encodeURIComponent(p.id)}">Switch to this plan</a>
      <a class="btn btn--secondary btn--block" href="calculator.html?kwh=${state.kwh}&run=1">Compare with my current plan</a>
      <button class="btn btn--wa btn--block" type="button" data-ask>Ask about this plan</button>
    </div>
    <p class="small">Prices come from the Eutility price sheet. Final pricing and terms are set by the retailer's contract.</p>`;
  sheetBody.querySelector('[data-ask]').addEventListener('click', () => openWhatsApp(
    `Hi Eutility, I'd like to know more about ${p.retailer} ${p.name} (about ${state.kwh} kWh/month).`,
  ));
  sheet.classList.add('is-open');
  sheet.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
  sheet.querySelector('.sheet__close').focus();
}
function closeSheet() {
  sheet.classList.remove('is-open');
  sheet.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
}
grid.addEventListener('click', (e) => {
  const b = e.target.closest('[data-detail]');
  if (b) openSheet(b.dataset.detail);
});
sheet.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', closeSheet));
addEventListener('keydown', (e) => { if (e.key === 'Escape' && sheet.classList.contains('is-open')) closeSheet(); });

render();
if (q.get('plan')) openSheet(q.get('plan'));
