import { initLayout } from '../layout.js';
import { AVAILABLE_PLANS, TARIFF } from '../calc.js';
import { META } from '../data/plans.js';
import * as I from '../icons.js';

initLayout();

const retailers = [...new Set(AVAILABLE_PLANS.map((p) => p.retailer))].filter((r) => r !== 'SP Group');

// Draft answers — review with Eutility (esp. switching process, fees and data handling) before launch.
const FAQ = [
  {
    group: 'Savings',
    items: [
      {
        q: 'How are my savings calculated?',
        a: `<p>We multiply your monthly usage (kWh) by each plan’s published rate, add any daily charge, and compare that with what you pay on your current plan. The difference × 12 is your yearly saving.</p>
            <ul><li>Discount-off-tariff plans use SP Group’s current regulated tariff (${TARIFF}¢/kWh).</li>
            <li>Time-of-use plans assume a share of your usage is at night (30% by default — you can change it under <em>Advanced assumptions</em>).</li>
            <li>Sign-up promotions are shown separately and not added to your savings.</li></ul>
            <p>It’s an estimate — your real bill depends on your actual usage and the retailer’s contract.</p>`,
      },
      {
        q: 'Which retailers can I compare?',
        a: `<p>We currently compare ${META.planCount} residential plans from: ${retailers.join(', ')} — plus SP Group’s regulated tariff as the baseline.</p><p>Rates are refreshed from our price sheet (last updated ${META.generated}).</p>`,
      },
      {
        q: 'Where do I find my monthly usage?',
        a: '<p>On your SP Group bill, look for the electricity usage in kWh for the month. If you’d rather not look it up, just send a photo of the bill on WhatsApp and we’ll read it for you.</p>',
      },
      {
        q: 'Does it cost anything to use Eutility?',
        a: '<p>Checking your savings is free and there’s no obligation to switch.</p>',
      },
    ],
  },
  {
    group: 'Switching',
    items: [
      {
        q: 'How do I switch?',
        a: '<p>Tap <strong>Switch Now</strong> on your results, or reply YES in WhatsApp. We’ll confirm the plan with you and help you sign up with the new retailer. The retailer then confirms your start date.</p>',
      },
      {
        q: 'Will my electricity supply be interrupted?',
        a: '<p>No. SP Group continues to deliver electricity through the same grid and meter. Only the company you buy electricity from — and your price — changes.</p>',
      },
      {
        q: 'What if I’m still in a contract?',
        a: '<p>Your current retailer may charge an early termination fee. We show each plan’s fee and deposit where the retailer publishes them, and can help you time the switch to avoid fees.</p>',
      },
      {
        q: 'Is there a deposit?',
        a: '<p>Some retailers ask for a security deposit depending on your home type and citizenship/residency status; others waive it. The deposit for the recommended plan is shown on your results.</p>',
      },
    ],
  },
  {
    group: 'WhatsApp',
    items: [
      {
        q: 'How does WhatsApp work?',
        a: `<p>Tap any <strong>Chat on WhatsApp</strong> button. WhatsApp opens with a message ready to send. Send it with a photo of your bill and we’ll reply with your savings (usually within about a minute).</p><p>On a computer without WhatsApp, scan the QR code with your phone instead.</p>`,
      },
      {
        q: 'What happens to my bill photo?',
        a: '<p>It’s used to read your usage and current plan so we can prepare your estimate. See our <a href="legal.html#privacy">Privacy Policy</a> for how data is stored and protected.</p>',
      },
    ],
  },
  {
    group: 'Referrals & rewards',
    items: [
      {
        q: 'How does the referral programme work?',
        a: '<p>Get your personal link on the <a href="referrals.html">Referrals</a> page and share it. When a friend checks their savings and switches through Eutility, the referral counts towards your rewards.</p>',
      },
      {
        q: 'What rewards are available?',
        a: '<p>Rewards and campaigns may include product gifts, vouchers or special prizes. Current campaign details are announced on the Referrals page and on WhatsApp.</p>',
      },
    ],
  },
  {
    group: 'Businesses',
    items: [
      {
        q: 'Can Eutility help my business?',
        a: '<p>Yes. Use the <a href="calculator.html#sme">SME calculator</a> to add each of your sites. Combining usage across locations can unlock a better aggregated rate. An energy consultant will then confirm a quote.</p>',
      },
    ],
  },
];

const list = document.getElementById('faq-list');
document.querySelector('[data-icon-search]').outerHTML = I.search;

function render(filter = '') {
  const f = filter.trim().toLowerCase();
  const strip = (h) => h.replace(/<[^>]+>/g, ' ').toLowerCase();
  let firstOpen = !f;
  const html = FAQ.map((g) => {
    const items = g.items.filter((it) => !f || it.q.toLowerCase().includes(f) || strip(it.a).includes(f));
    if (!items.length) return '';
    return `<div class="faq-group"><h2>${g.group}</h2><div class="acc">${items.map((it) => {
      const open = firstOpen || !!f;
      firstOpen = false;
      return `<details${open ? ' open' : ''}><summary>${it.q}</summary><div class="acc__body">${it.a}</div></details>`;
    }).join('')}</div></div>`;
  }).join('');
  list.innerHTML = html || `<div class="faq-empty"><p class="h4" style="color:var(--text)">No matches for “${filter.replace(/</g, '&lt;')}”</p><p style="margin-top:8px">Try another word, or <a href="#" data-wa data-wa-message="Hi Eutility, I have a question.">ask us on WhatsApp</a>.</p></div>`;

  // One item open at a time (when not searching)
  list.querySelectorAll('details').forEach((d) => d.addEventListener('toggle', () => {
    if (d.open && !document.getElementById('faq-q').value) {
      list.querySelectorAll('details[open]').forEach((o) => { if (o !== d) o.open = false; });
    }
  }));
}
render();
document.getElementById('faq-q').addEventListener('input', (e) => render(e.target.value));
